# App name

Surfaces Appsmith app for viewing accounts

### The following information is displayed:

* info1
* info2
* info3

Please submit bug reports to [Insert Link](). Pull requests are welcome.

To run locally, in `zcli.apps.config.json` set the value of `app_id` to `"local_id"`

### Screenshot(s):
[put your screenshots down here.]
